package com.demo.employee;

import java.math.BigInteger;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
	

	@Document(collection="employee")
	public class Employee {
	    @Id
	    private String id;

	    @NotBlank
	    private Integer eID;

	    

	    private String name;
	    private Double salary;
	    private String role;
	    private String project;
	    

	    public Employee(String string) {
	        super();
	    }

	    public Employee(String string,String role) {
	        this.name=string;
	    }

	    public String getId() {
	        return id;
	    }

	    public void setId(String id) {
	        this.id = id;
	    }

	    
	    public Integer geteID() {
			return eID;
		}

		public void seteID(Integer eID) {
			this.eID = eID;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Double getSalary() {
			return salary;
		}

		public void setSalary(Double salary) {
			this.salary = salary;
		}

		public String getRole() {
			return role;
		}

		public void setRole(String role) {
			this.role = role;
		}

		public String getProject() {
			return project;
		}

		public void setProject(String project) {
			this.project = project;
		}

		@Override
	    public String toString() {
	        return String.format(
	                "Todo[id=%s, Name='%s', Role='%s']",
	                id, name, role);
	    }
	}


