package com.demo.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RequestMapping("/api")
@RestController
public class Controller {
	
	@Autowired
    EmployeeRepository employeeRepository;

	
	@RequestMapping("/trial")
	public Employee employee(String name) {
		
		return new Employee(String.format("Hello", name));
	}
	
	@RequestMapping("/")
	public String index(){
		return "Welcome to spring boot";
		}
	@GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        /*Sort sortByCreatedAtDesc = new Sort(Sort.Direction.DESC, "createdAt");*/
        return employeeRepository.findAll();
    }
	
	

}
